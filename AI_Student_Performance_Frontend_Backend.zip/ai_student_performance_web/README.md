# AI-Based Student Performance Prediction System

A responsive front end built with HTML and CSS, plus a Python Flask back end. Users enter attendance, study hours, previous marks, and assignment completion to receive an estimated score.

## Technologies
- HTML5 and CSS3 (front end)
- Python and Flask (back end)
- Jinja templates for connecting the front end to the server

## Run locally
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the app:
   ```bash
   python app.py
   ```
5. Open `http://127.0.0.1:5000` in your browser.

## Upload to GitHub
Create a repository named `ai-student-performance-prediction`, then upload `app.py`, `requirements.txt`, `README.md`, `templates/index.html`, and `static/style.css`.

## Important limitation
The score uses a simple illustrative weighted formula, not a trained AI model. It is only a student project demo and must not be used to make real academic decisions. Replace the formula with a properly trained and evaluated model if your project requires machine learning.
