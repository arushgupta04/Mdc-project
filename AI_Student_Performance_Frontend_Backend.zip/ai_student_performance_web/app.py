from flask import Flask, render_template, request
import os

app = Flask(__name__)

def predict_score(attendance, study_hours, previous_marks, assignments):
    """
    Transparent demo scoring formula (not a trained/validated model).
    Replace with a trained ML model and real, ethically collected data for research use.
    """
    score = (
        0.30 * previous_marks
        + 0.25 * attendance
        + 0.25 * assignments
        + 0.20 * min(study_hours / 8 * 100, 100)
    )
    return round(max(0, min(score, 100)), 1)

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    error = None
    values = {"attendance": "80", "study_hours": "3", "previous_marks": "65", "assignments": "75"}
    if request.method == "POST":
        try:
            values = {key: request.form.get(key, "").strip() for key in values}
            attendance = float(values["attendance"])
            study_hours = float(values["study_hours"])
            previous_marks = float(values["previous_marks"])
            assignments = float(values["assignments"])
            if not 0 <= attendance <= 100:
                raise ValueError("Attendance must be between 0 and 100.")
            if not 0 <= study_hours <= 24:
                raise ValueError("Study hours must be between 0 and 24.")
            if not 0 <= previous_marks <= 100:
                raise ValueError("Previous marks must be between 0 and 100.")
            if not 0 <= assignments <= 100:
                raise ValueError("Assignment completion must be between 0 and 100.")
            score = predict_score(attendance, study_hours, previous_marks, assignments)
            if score >= 75:
                category = "Strong performance estimate"
                advice = "Keep up the current study routine and continue asking for feedback."
            elif score >= 50:
                category = "Moderate performance estimate"
                advice = "A regular study plan, practice questions, and timely assignment work may help."
            else:
                category = "Needs additional support"
                advice = "Consider discussing learning goals and support options with a teacher."
            result = {"score": score, "category": category, "advice": advice}
        except (ValueError, TypeError):
            error = "Please enter valid numbers within the ranges shown."
    return render_template("index.html", result=result, error=error, values=values)

if __name__ == "__main__":
    app.run(debug=True)
