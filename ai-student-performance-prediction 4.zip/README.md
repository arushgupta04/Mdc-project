# AI-Based Student Performance Prediction System

A small MDC project that demonstrates how machine learning can estimate a student's final score from attendance, daily study hours, previous marks, and assignment completion.

## Features
- Interactive Streamlit interface
- Random Forest regression model
- Estimated score out of 100
- Simple guidance messages based on the estimate
- Displays model evaluation metrics
- Includes a small downloadable synthetic demo dataset

## Important note
The included dataset is **synthetic and very small**. It is for learning and demonstration only, not for making real academic decisions. Predictions may be inaccurate and should never replace a teacher's judgment or a student's own context.

## Run locally
1. Install Python 3.10 or newer.
2. Download or clone this repository.
3. Open a terminal in the project folder and run:

   ```bash
   pip install -r requirements.txt
   streamlit run app.py
   ```

4. Open the local URL shown in the terminal (usually `http://localhost:8501`).

## Upload to GitHub
1. Create a new repository on GitHub named `ai-student-performance-prediction`.
2. Upload `app.py`, `requirements.txt`, and `README.md` (or upload the whole project folder).
3. Commit the files.
4. Copy the repository URL into your MDC tracking sheet.

## Suggested project description
An AI-based web app that estimates student performance using attendance, study hours, previous marks, and assignment completion.

## Technologies
Python, Streamlit, Pandas, Scikit-learn, Random Forest Regression.
