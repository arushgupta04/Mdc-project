import streamlit as st
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score

st.set_page_config(page_title="Student Performance Predictor", page_icon="🎓", layout="wide")
st.title("🎓 AI-Based Student Performance Prediction System")
st.write("Estimate a student's final score using attendance, study habits, previous marks, and assignment completion.")
st.caption("Educational demo only: predictions are estimates, not definitive judgments about a student.")

@st.cache_data
def sample_data():
    # Synthetic demonstration data; not real student records.
    data = pd.DataFrame({
        "attendance": [55, 62, 70, 75, 80, 85, 90, 95, 68, 78, 88, 72, 60, 92, 83, 77, 65, 98, 73, 86],
        "study_hours": [1, 2, 2, 3, 3, 4, 5, 6, 2, 3, 5, 2, 1, 6, 4, 3, 2, 7, 3, 4],
        "previous_marks": [42, 48, 55, 60, 65, 72, 78, 88, 52, 63, 82, 58, 45, 91, 75, 62, 50, 95, 57, 80],
        "assignments_completed": [40, 50, 60, 65, 70, 80, 85, 95, 55, 70, 90, 60, 45, 100, 85, 72, 50, 100, 65, 88],
        "final_score": [38, 45, 54, 58, 64, 72, 79, 91, 49, 65, 85, 56, 41, 94, 77, 63, 47, 97, 59, 82]
    })
    return data

data = sample_data()
features = ["attendance", "study_hours", "previous_marks", "assignments_completed"]
X, y = data[features], data["final_score"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)
model = RandomForestRegressor(n_estimators=150, random_state=42)
model.fit(X_train, y_train)
preds = model.predict(X_test)
mae = mean_absolute_error(y_test, preds)
r2 = r2_score(y_test, preds)

left, right = st.columns([1, 1])
with left:
    st.subheader("Enter student details")
    attendance = st.slider("Attendance (%)", 0, 100, 80)
    study_hours = st.slider("Study hours per day", 0, 12, 3)
    previous_marks = st.slider("Previous marks (%)", 0, 100, 65)
    assignments = st.slider("Assignments completed (%)", 0, 100, 75)
    if st.button("Predict performance", type="primary", use_container_width=True):
        row = pd.DataFrame([[attendance, study_hours, previous_marks, assignments]], columns=features)
        score = float(model.predict(row)[0])
        score = max(0, min(100, score))
        st.session_state["prediction"] = score
with right:
    st.subheader("Prediction")
    if "prediction" in st.session_state:
        score = st.session_state["prediction"]
        st.metric("Estimated final score", f"{score:.1f}/100")
        if score >= 75:
            st.success("Likely strong performance. Encourage the student to maintain good habits.")
        elif score >= 50:
            st.info("Potential to improve. Regular practice and feedback may help.")
        else:
            st.warning("Consider offering additional academic support and checking for barriers.")
    else:
        st.info("Adjust the inputs and click **Predict performance**.")
    st.subheader("Model evaluation")
    st.write(f"Mean absolute error on the demo test split: **{mae:.2f} points**")
    st.write(f"R² score on the demo test split: **{r2:.2f}**")
    st.caption("The dataset is tiny and synthetic; these metrics are only for demonstrating the workflow.")

st.divider()
st.subheader("Demo dataset")
st.dataframe(data, use_container_width=True, hide_index=True)
csv = data.to_csv(index=False).encode("utf-8")
st.download_button("Download demo dataset (CSV)", csv, "student_performance_demo.csv", "text/csv")

with st.expander("How it works"):
    st.markdown("""
    1. Collect example inputs: attendance, study hours, previous marks, and assignment completion.
    2. Train a Random Forest regression model on a small synthetic dataset.
    3. Predict an estimated final score from the entered values.
    4. Use the result as a conversation starter for support—not as the sole basis for decisions.
    """)
